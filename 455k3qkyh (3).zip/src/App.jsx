import { useState } from "react";

import Login from "./components/Login";
import AdminDashboard from "./pages/AdminDashboard";
import StaffDashboard from "./pages/StaffDashboard";
import StudentDashboard from "./pages/StudentDashboard";
import AnalyticsDashboard from "./pages/AnalyticsDashboard";

function App() {
  const [user, setUser] = useState(null);

  // Login
  const handleLogin = (loggedInUser) => {
    setUser(loggedInUser);
  };

  // Logout
  const handleLogout = () => {
    setUser(null);
  };

  // Show Login when user is not logged in
  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  // =========================
  // ADMIN DASHBOARD
  // =========================
  if (user.role === "admin") {
    return (
      <AdminDashboard
        user={user}
        onLogout={handleLogout}
      />
    );
  }

  // =========================
  // STAFF DASHBOARD
  // =========================
  if (user.role === "staff") {
    return (
      <StaffDashboard
        user={user}
        onLogout={handleLogout}
      />
    );
  }

  // =========================
  // STUDENT DASHBOARD
  // =========================
  if (user.role === "student") {
    return (
      <StudentDashboard
        user={user}
        onLogout={handleLogout}
      />
    );
  }

  // =========================
  // ANALYTICS DASHBOARD
  // =========================
  if (user.role === "analytics") {
    return (
      <AnalyticsDashboard
        user={user}
        onLogout={handleLogout}
      />
    );
  }

  // Invalid role
  return (
    <div>
      <h2>Invalid User Role</h2>
      <button onClick={handleLogout}>Back to Login</button>
    </div>
  );
}

export default App;