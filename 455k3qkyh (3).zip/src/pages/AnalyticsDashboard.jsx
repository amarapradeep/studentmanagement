import { useMemo, useState } from "react";

import studentsData from "../data/students";

import {
  calculateSuccessScore,
  calculateRisk,
  getScoreDrivers,
  getRiskDrivers,
  getStudentSegment,
} from "../utils/analytics";

function AnalyticsDashboard({ onLogout }) {
  const [selectedStudent, setSelectedStudent] =
    useState(null);

  const students = useMemo(() => {
    return studentsData.map((student) => ({
      ...student,

      successScore:
        calculateSuccessScore(student),

      riskLevel:
        calculateRisk(student),

      successDrivers:
        getScoreDrivers(student),

      riskDrivers:
        getRiskDrivers(student),

      segment:
        getStudentSegment(student),
    }));
  }, []);

  const totalStudents = students.length;

  const highRisk = students.filter(
    (s) => s.riskLevel === "HIGH"
  ).length;

  const mediumRisk = students.filter(
    (s) => s.riskLevel === "MEDIUM"
  ).length;

  const lowRisk = students.filter(
    (s) => s.riskLevel === "LOW"
  ).length;

  const averageScore = Math.round(
    students.reduce(
      (total, student) =>
        total + student.successScore,
      0
    ) / students.length
  );

  return (
    <div className="dashboard">

      <nav className="navbar">

        <h2>
          Smart Campus Analytics
        </h2>

        <button onClick={onLogout}>
          Logout
        </button>

      </nav>

      <div className="analytics-dashboard">

        <div className="analytics-header">

          <div>
            <h1>
              Student Success Analytics
            </h1>

            <p>
              Predict, optimize and improve
              student success.
            </p>
          </div>

        </div>

        {/* KPI CARDS */}

        <div className="analytics-cards">

          <div className="analytics-card">

            <span>
              Total Students
            </span>

            <strong>
              {totalStudents}
            </strong>

          </div>

          <div className="analytics-card">

            <span>
              Average Success Score
            </span>

            <strong>
              {averageScore}
            </strong>

          </div>

          <div className="analytics-card high-card">

            <span>
              High Risk
            </span>

            <strong>
              {highRisk}
            </strong>

          </div>

          <div className="analytics-card">

            <span>
              Medium Risk
            </span>

            <strong>
              {mediumRisk}
            </strong>

          </div>

          <div className="analytics-card">

            <span>
              Low Risk
            </span>

            <strong>
              {lowRisk}
            </strong>

          </div>

        </div>

        {/* STUDENT TABLE */}

        <section className="analytics-section">

          <h2>
            Student Success Overview
          </h2>

          <div className="table-container">

            <table>

              <thead>

                <tr>
                  <th>Student</th>
                  <th>Department</th>
                  <th>Success Score</th>
                  <th>Risk</th>
                  <th>Segment</th>
                  <th>Action</th>
                </tr>

              </thead>

              <tbody>

                {students.map((student) => (

                  <tr key={student.id}>

                    <td>
                      <strong>
                        {student.name}
                      </strong>

                      <br />

                      <small>
                        {student.rollNumber}
                      </small>
                    </td>

                    <td>
                      {student.department}
                    </td>

                    <td>

                      <div className="score-container">

                        <div className="score-bar">

                          <div
                            className="score-fill"
                            style={{
                              width: `${student.successScore}%`,
                            }}
                          />

                        </div>

                        <strong>
                          {student.successScore}
                        </strong>

                      </div>

                    </td>

                    <td>

                      <span
                        className={`risk ${student.riskLevel.toLowerCase()}`}
                      >
                        {student.riskLevel}
                      </span>

                    </td>

                    <td>
                      {student.segment}
                    </td>

                    <td>

                      <button
                        className="view-button"
                        onClick={() =>
                          setSelectedStudent(student)
                        }
                      >
                        View Insights
                      </button>

                    </td>

                  </tr>

                ))}

              </tbody>

            </table>

          </div>

        </section>

        {/* RISK SUMMARY */}

        <section className="analytics-section">

          <h2>
            Risk Distribution
          </h2>

          <div className="risk-distribution">

            <div>

              <span>LOW</span>

              <div className="distribution-bar">

                <div
                  className="distribution-low"
                  style={{
                    width: `${
                      (lowRisk /
                        totalStudents) *
                      100
                    }%`,
                  }}
                />

              </div>

              <strong>
                {lowRisk}
              </strong>

            </div>

            <div>

              <span>MEDIUM</span>

              <div className="distribution-bar">

                <div
                  className="distribution-medium"
                  style={{
                    width: `${
                      (mediumRisk /
                        totalStudents) *
                      100
                    }%`,
                  }}
                />

              </div>

              <strong>
                {mediumRisk}
              </strong>

            </div>

            <div>

              <span>HIGH</span>

              <div className="distribution-bar">

                <div
                  className="distribution-high"
                  style={{
                    width: `${
                      (highRisk /
                        totalStudents) *
                      100
                    }%`,
                  }}
                />

              </div>

              <strong>
                {highRisk}
              </strong>

            </div>

          </div>

        </section>

      </div>

      {/* INSIGHT MODAL */}

      {selectedStudent && (

        <div className="modal">

          <div className="modal-content insight-modal">

            <h2>
              {selectedStudent.name}
            </h2>

            <p>
              {selectedStudent.rollNumber}
            </p>

            <hr />

            <h3>
              Success Score
            </h3>

            <div className="large-score">
              {selectedStudent.successScore}
              <span>/100</span>
            </div>

            <h3>
              Risk Level
            </h3>

            <span
              className={`risk ${selectedStudent.riskLevel.toLowerCase()}`}
            >
              {selectedStudent.riskLevel}
            </span>

            <h3>
              Student Segment
            </h3>

            <p>
              {selectedStudent.segment}
            </p>

            <h3>
              Positive Drivers
            </h3>

            {selectedStudent.successDrivers.length >
            0 ? (
              <ul>
                {selectedStudent.successDrivers.map(
                  (driver, index) => (
                    <li key={index}>
                      {driver}
                    </li>
                  )
                )}
              </ul>
            ) : (
              <p>
                No major positive drivers
                identified.
              </p>
            )}

            <h3>
              Risk Drivers
            </h3>

            {selectedStudent.riskDrivers.length >
            0 ? (
              <ul>
                {selectedStudent.riskDrivers.map(
                  (driver, index) => (
                    <li key={index}>
                      {driver}
                    </li>
                  )
                )}
              </ul>
            ) : (
              <p>
                No major risk drivers identified.
              </p>
            )}

            <button
              className="cancel-button"
              onClick={() =>
                setSelectedStudent(null)
              }
            >
              Close
            </button>

          </div>

        </div>

      )}

    </div>
  );
}

export default AnalyticsDashboard;