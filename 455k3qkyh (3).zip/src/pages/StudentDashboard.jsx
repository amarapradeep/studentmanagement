import { useState } from "react";
import initialStudents from "../data/students";

function StudentDashboard({ onLogout }) {
  // Demo: logged-in student is the first student
  const [student] = useState(initialStudents[0]);

  const assignmentPercentage =
    student.assignmentsTotal > 0
      ? Math.round(
          (student.assignmentsCompleted /
            student.assignmentsTotal) *
            100
        )
      : 0;

  const getRiskMessage = () => {
    if (student.riskLevel === "LOW") {
      return "You are performing well. Keep up the good work!";
    }

    if (student.riskLevel === "MEDIUM") {
      return "Your performance needs some attention. Try to improve your weak areas.";
    }

    return "You are at high academic risk. Please contact your staff member.";
  };

  return (
    <div className="dashboard">

      {/* Navbar */}

      <nav className="navbar">

        <h2>Student Dashboard</h2>

        <button onClick={onLogout}>
          Logout
        </button>

      </nav>

      <div className="student-dashboard">

        {/* Welcome */}

        <div className="welcome-section">

          <div>
            <h1>
              Welcome, {student.name} 👋
            </h1>

            <p>
              Here is your academic progress overview.
            </p>
          </div>

          <div className="student-roll">
            {student.rollNumber}
          </div>

        </div>

        {/* Profile */}

        <section className="dashboard-section">

          <h2>Student Profile</h2>

          <div className="profile-grid">

            <div className="profile-item">
              <span>Roll Number</span>
              <strong>
                {student.rollNumber}
              </strong>
            </div>

            <div className="profile-item">
              <span>Name</span>
              <strong>
                {student.name}
              </strong>
            </div>

            <div className="profile-item">
              <span>Department</span>
              <strong>
                {student.department}
              </strong>
            </div>

            <div className="profile-item">
              <span>Semester</span>
              <strong>
                {student.semester}
              </strong>
            </div>

            <div className="profile-item">
              <span>Staff Member</span>
              <strong>
                {student.staffMember}
              </strong>
            </div>

          </div>

        </section>

        {/* Academic Cards */}

        <section className="dashboard-section">

          <h2>Academic Overview</h2>

          <div className="student-cards">

            <div className="student-card">

              <div className="card-icon">
                📅
              </div>

              <div>
                <span>Attendance</span>

                <h3>
                  {student.attendance}%
                </h3>
              </div>

            </div>

            <div className="student-card">

              <div className="card-icon">
                🎓
              </div>

              <div>
                <span>CGPA</span>

                <h3>
                  {student.cgpa}
                </h3>
              </div>

            </div>

            <div className="student-card">

              <div className="card-icon">
                📝
              </div>

              <div>
                <span>Internal Marks</span>

                <h3>
                  {student.internalMarks}
                </h3>
              </div>

            </div>

            <div className="student-card">

              <div className="card-icon">
                ⚠️
              </div>

              <div>
                <span>Backlogs</span>

                <h3>
                  {student.backlogs}
                </h3>
              </div>

            </div>

          </div>

        </section>

        {/* Progress */}

        <section className="dashboard-section">

          <h2>Academic Progress</h2>

          <div className="progress-container">

            {/* Attendance */}

            <div className="progress-item">

              <div className="progress-header">

                <span>
                  Attendance
                </span>

                <strong>
                  {student.attendance}%
                </strong>

              </div>

              <div className="progress-bar">

                <div
                  className="progress-fill"
                  style={{
                    width: `${student.attendance}%`,
                  }}
                />

              </div>

            </div>

            {/* Assignments */}

            <div className="progress-item">

              <div className="progress-header">

                <span>
                  Assignments
                </span>

                <strong>
                  {student.assignmentsCompleted}/
                  {student.assignmentsTotal}
                </strong>

              </div>

              <div className="progress-bar">

                <div
                  className="progress-fill"
                  style={{
                    width: `${assignmentPercentage}%`,
                  }}
                />

              </div>

            </div>

            {/* Overall Progress */}

            <div className="progress-item">

              <div className="progress-header">

                <span>
                  Overall Progress
                </span>

                <strong>
                  {student.progress}%
                </strong>

              </div>

              <div className="progress-bar">

                <div
                  className="progress-fill"
                  style={{
                    width: `${student.progress}%`,
                  }}
                />

              </div>

            </div>

          </div>

        </section>

        {/* Risk */}

        <section className="dashboard-section">

          <h2>Academic Risk Assessment</h2>

          <div
            className={`risk-card ${student.riskLevel.toLowerCase()}`}
          >

            <div className="risk-icon">

              {student.riskLevel === "LOW" && "✅"}

              {student.riskLevel === "MEDIUM" && "⚠️"}

              {student.riskLevel === "HIGH" && "🚨"}

            </div>

            <div className="risk-content">

              <h2>
                {student.riskLevel} RISK
              </h2>

              <p>
                {getRiskMessage()}
              </p>

            </div>

          </div>

        </section>

      </div>

    </div>
  );
}

export default StudentDashboard;