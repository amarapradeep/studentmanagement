export function calculateSuccessScore(student) {
  const assignmentPercentage =
    student.assignmentsTotal > 0
      ? (student.assignmentsCompleted /
          student.assignmentsTotal) *
        100
      : 0;

  /*
    Student Success Score

    Academic       = 25%
    Attendance     = 15%
    LMS            = 10%
    Engagement     = 10%
    Placement      = 15%
    Skills         = 15%
    Feedback       = 10%
  */

  const academicScore =
    student.cgpa * 10 * 0.6 +
    student.internalMarks * 0.4;

  const attendanceScore =
    student.attendance;

  const lmsScore =
    student.lmsLoginFrequency * 0.5 +
    assignmentPercentage * 0.5;

  const engagementScore =
    Math.min(
      100,
      student.events * 5 +
        student.clubs * 10 +
        student.hackathons * 15 +
        student.certifications * 10
    );

  const placementScore =
    student.aptitudeScore * 0.3 +
    student.codingScore * 0.4 +
    student.mockInterviewScore * 0.3;

  const skillsScore =
    student.technicalSkillScore * 0.6 +
    student.softSkillScore * 0.4;

  const feedbackScore =
    student.studentSatisfaction * 0.5 +
    student.facultyFeedback * 0.5;

  const score =
    academicScore * 0.25 +
    attendanceScore * 0.15 +
    lmsScore * 0.10 +
    engagementScore * 0.10 +
    placementScore * 0.15 +
    skillsScore * 0.15 +
    feedbackScore * 0.10;

  return Math.round(score);
}
export function calculateRisk(student) {
  let riskPoints = 0;

  if (student.cgpa < 6) {
    riskPoints += 3;
  } else if (student.cgpa < 7) {
    riskPoints += 2;
  }

  if (student.attendance < 60) {
    riskPoints += 3;
  } else if (student.attendance < 75) {
    riskPoints += 2;
  }

  if (student.backlogs >= 3) {
    riskPoints += 3;
  } else if (student.backlogs >= 1) {
    riskPoints += 2;
  }

  if (student.codingScore < 50) {
    riskPoints += 2;
  }

  if (student.aptitudeScore < 50) {
    riskPoints += 2;
  }

  if (student.progress < 50) {
    riskPoints += 2;
  }

  if (riskPoints >= 7) {
    return "HIGH";
  }

  if (riskPoints >= 4) {
    return "MEDIUM";
  }

  return "LOW";
}
export function getScoreDrivers(student) {
  const drivers = [];

  if (student.cgpa >= 8) {
    drivers.push("Strong CGPA");
  }

  if (student.attendance >= 80) {
    drivers.push("Good attendance");
  }

  if (student.assignmentsCompleted >= 8) {
    drivers.push("Strong assignment completion");
  }

  if (student.codingScore >= 75) {
    drivers.push("Strong coding performance");
  }

  if (student.technicalSkillScore >= 75) {
    drivers.push("Strong technical skills");
  }

  if (student.hackathons >= 2) {
    drivers.push("Good hackathon participation");
  }

  if (student.certifications >= 2) {
    drivers.push("Good certification activity");
  }

  return drivers;
}


export function getRiskDrivers(student) {
  const drivers = [];

  if (student.attendance < 75) {
    drivers.push("Low attendance");
  }

  if (student.cgpa < 7) {
    drivers.push("Low CGPA");
  }

  if (student.backlogs > 0) {
    drivers.push(`${student.backlogs} backlog(s)`);
  }

  if (student.codingScore < 60) {
    drivers.push("Low coding score");
  }

  if (student.aptitudeScore < 60) {
    drivers.push("Low aptitude score");
  }

  if (student.lmsLoginFrequency < 60) {
    drivers.push("Low LMS activity");
  }

  if (
    student.assignmentsCompleted <
    student.assignmentsTotal * 0.6
  ) {
    drivers.push("Low assignment completion");
  }

  return drivers;
}
export function getStudentSegment(student) {
  const academicHigh = student.cgpa >= 8;
  const placementHigh =
    student.aptitudeScore >= 70 &&
    student.codingScore >= 70;

  const placementLow =
    student.aptitudeScore < 60 ||
    student.codingScore < 60;

  if (academicHigh && placementLow) {
    return "High Academic / Low Placement Readiness";
  }

  if (
    student.attendance < 60 &&
    student.cgpa < 7
  ) {
    return "Academic Intervention Required";
  }

  if (
    student.cgpa >= 8 &&
    placementHigh
  ) {
    return "High Performer";
  }

  if (
    student.hackathons >= 2 &&
    student.technicalSkillScore >= 75
  ) {
    return "Industry Ready";
  }

  if (
    student.cgpa >= 7 &&
    student.codingScore >= 70
  ) {
    return "Placement Potential";
  }

  return "Needs Continuous Monitoring";
}