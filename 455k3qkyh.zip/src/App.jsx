import { useState } from "react";

import Login from "./components/Login";
import AdminDashboard from "./pages/AdminDashboard";
import StaffDashboard from "./pages/StaffDashboard";
import StudentDashboard from "./pages/StudentDashboard";
import AnalyticsDashboard from "./pages/AnalyticsDashboard";

function App() {
  const [user, setUser] = useState(null);

  const handleLogin = (loggedInUser) => {
    setUser(loggedInUser);
  };

  const handleLogout = () => {
    setUser(null);
  };

  // Show Login if user is not logged in
  if (!user) {
    return <Login onLogin={handleLogin} />;
  }

  // Admin
  if (user.role === "admin") {
    return (
      <AnalyticsDashboard
        user={user}
        onLogout={handleLogout}
      />
    );
  }

  // Staff
  if (user.role === "staff") {
    return (
      <StaffDashboard
        user={user}
        onLogout={handleLogout}
      />
    );
  }

  // Student
  if (user.role === "student") {
    return (
      <StudentDashboard
        user={user}
        onLogout={handleLogout}
      />
    );
  }

  return null;
}

export default App;
