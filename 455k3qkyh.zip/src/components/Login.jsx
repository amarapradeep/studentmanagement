import { useState } from "react";

function Login({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("student");
  const [error, setError] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();

    if (!username || !password) {
      setError("Please enter username and password");
      return;
    }

    // Demo authentication
    const users = {
      admin: {
        username: "admin",
        password: "admin123",
        role: "admin",
      },
      staff: {
        username: "staff",
        password: "staff123",
        role: "staff",
      },
      student: {
        username: "student",
        password: "student123",
        role: "student",
      },
    };

    const user = users[role];

    if (
      username === user.username &&
      password === user.password
    ) {
      setError("");
      onLogin(user);
    } else {
      setError("Invalid username or password");
    }
  };

  return (
    <div className="login-container">
      <div className="login-box">

        <h1>Student Management System</h1>

        <p className="login-subtitle">
          Login to continue
        </p>

        <form onSubmit={handleLogin}>

          <label>Role</label>

          <select
            value={role}
            onChange={(e) => setRole(e.target.value)}
          >
            <option value="admin">Admin</option>
            <option value="staff">Staff</option>
            <option value="student">Student</option>
          </select>

          <label>Username</label>

          <input
            type="text"
            placeholder="Enter username"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
          />

          <label>Password</label>

          <input
            type="password"
            placeholder="Enter password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          {error && (
            <p className="error">
              {error}
            </p>
          )}

          <button type="submit">
            Login
          </button>

        </form>

        <div className="demo-login">

          <p>Demo Accounts</p>

          <small>
            Admin: admin / admin123
          </small>

          <small>
            Staff: staff / staff123
          </small>

          <small>
            Student: student / student123
          </small>

        </div>

      </div>
    </div>
  );
}

export default Login;